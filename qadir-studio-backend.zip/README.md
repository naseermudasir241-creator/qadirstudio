
# Qadir Studio - Backend (Express + MongoDB)

## What this contains
- Simple Express server that serves the provided frontend from `/public`
- API endpoints:
  - `GET /api/services` - Returns services list
  - `GET /api/team` - Returns team members
  - `POST /api/contact` - Save contact messages (MongoDB)
  - `POST /api/auth/register` - Register user (basic, stores hashed password)
  - `POST /api/auth/login` - Login, returns JWT token

## Deployment on Render
1. Create a new Web Service on Render.
2. Set the Build Command to: `npm install`
3. Set the Start Command to: `npm start`
4. Add environment variables from `.env.example` in Render UI (especially `MONGO_URI` and `JWT_SECRET`).

## Local development
1. Copy `.env.example` to `.env` and fill values.
2. `npm install`
3. `npm run dev` (requires nodemon) or `npm start`

## Notes
- This is a minimal, ready-to-deploy backend intended to match the provided static frontend.
- For production, enable proper validation, rate-limiting, HTTPS, and stronger security practices.
