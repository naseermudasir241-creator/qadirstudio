
const express = require('express');
const router = express.Router();

const team = [
  { id: 1, name: 'Qadir Ahmed', title: 'Founder & CEO', img: 'https://randomuser.me/api/portraits/men/32.jpg' },
  { id: 2, name: 'Ayesha Khan', title: 'Head of Production', img: 'https://randomuser.me/api/portraits/women/44.jpg' },
  { id: 3, name: 'Bilal Siddiqui', title: 'Technical Director', img: 'https://randomuser.me/api/portraits/men/22.jpg' },
  { id: 4, name: 'Fatima Ali', title: 'Creative Director', img: 'https://randomuser.me/api/portraits/women/65.jpg' }
];

router.get('/', (req, res) => {
  res.json({ success: true, data: team });
});

module.exports = router;
