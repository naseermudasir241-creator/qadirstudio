
const express = require('express');
const router = express.Router();

// Hardcoded services list to match the frontend content
const services = [
  { id: 1, category: 'Music', title: 'Beat Making', description: 'Professional beat production in any genre with high-quality output', price: '₨2,000' },
  { id: 2, category: 'Music', title: 'Mixing & Mastering', description: 'Professional audio mixing and mastering services for your tracks', price: '₨2,500' },
  { id: 3, category: 'Video', title: 'Video Editing', description: 'High-quality video editing per minute of footage', price: '₨566/minute' },
  // ... you can extend
];

router.get('/', (req, res) => {
  res.json({ success: true, data: services });
});

module.exports = router;
